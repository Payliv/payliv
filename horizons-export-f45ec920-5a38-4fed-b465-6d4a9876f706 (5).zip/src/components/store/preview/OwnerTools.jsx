import React from 'react';

const OwnerTools = ({ isOwner }) => {
    if (!isOwner) {
        return null;
    }
    
    return null;
};

export default OwnerTools;